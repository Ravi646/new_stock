$(function() {

    $('#login-form-link').click(function(e) {
		$("#login-form").delay(100).fadeIn(100);
 		$("#register-form").fadeOut(100);
		$('#register-form-link').removeClass('active');
		$(this).addClass('active');
		e.preventDefault();
	});
	$('#register-form-link').click(function(e) {
		$("#register-form").delay(100).fadeIn(100);
 		$("#login-form").fadeOut(100);
		$('#login-form-link').removeClass('active');
		$(this).addClass('active');
		e.preventDefault();
	});
	  
  $(".editLink").on('click', function(e){
      e.preventDefault();
      $("#fileInput:hidden").trigger('click');
  });
$("#fileInput").on('change', function(){
        var image = $('#fileInput').val();
        var img_ex = /(\.jpg|\.jpeg|\.png|\.gif)$/i;
        
        //validate file type
        if(!img_ex.exec(image)){
            alert('Please upload only .jpg/.jpeg/.png/.gif file.');
            $('#fileInput').val('');
            return false;
        }
    });
 $('#update_pic').on('click', function(e) {
  e.preventDefault(); 
  var form = $(e.target);
  var value = $('#flex-item')[0];
  var formData = new FormData(value);
   $.ajax({
        type: 'POST',
        url:base_url('user-update'),
        enctype: 'multipart/form-data',
        datatype:'Json',
        data: formData,
        contentType: false,
        processData: false, 
        cache:false,
        beforeSend: function() {
        // setting a timeout
       $(".loading").show();
    },
        success: function(data) {
  			var img_path = base_url(data);
  			$(".profile_pic").attr('src',data);
  			 $(".loading").hide();
}

});
});
});



