function base_url(page){
	var base_url = $('body').data('base_url');
	return base_url+page;
}

function readURL(file_id,img_rep_id,remove,custom_class,input) {
  var remove_html = '';
  
  if (remove == 'yes') {
    remove_html = '<br><button data-file_id="'+file_id+'" data-prev_id="'+img_rep_id+'" type="button" class="btn btn-danger remove_prev">Remove</button>';
  }

  var reader = new FileReader();
  if (input.files && input.files[0]) {
    if (input.files[0].type.match('image')) {
      reader.onload = function(e) {
        var prev_html = '<img class="'+custom_class+'" src="'+e.target.result+'" height="150" width="150">'+remove_html;
        $('#'+img_rep_id).html(prev_html);
      }

      reader.readAsDataURL(input.files[0]);
    }
    else{
      reader.onload = function(e) {
        var prev_html = '<video src="'+e.target.result+'" height="150" width="150"></video>'+remove_html;
        $('#'+img_rep_id).html(prev_html);
      }

      reader.readAsDataURL(input.files[0]);
    }

    $('#'+file_id).hide();
  }
}

$(".img_upload").change(function() {
  var file_id = $(this).attr('id');
  var img_rep_id = $(this).data('img_rep_id');
  var remove = $(this).data('remove');
  var custom_class = $(this).data('class');
  readURL(file_id,img_rep_id,remove,custom_class,this);
});

$(document).on('click','.remove_prev', function(){
  var file_id = $(this).data('file_id');
  var prev_id = $(this).data('prev_id');

  $('#'+file_id).val('').show();
  $('#'+prev_id).empty();
});

/* iCheck Starts */
/* Flat Green Color Scheme for iCheck Starts*/
    $('.flat-green').iCheck({
      checkboxClass: 'icheckbox_flat-green',
      radioClass   : 'iradio_flat-green'
    });
/* Flat Green Color Scheme for iCheck Ends*/
/* iCheck Ends */

$('#sel_all').on('ifChecked', function(){
  $('.sel_data').iCheck('check'); 
});

$('#sel_all').on('ifUnchecked', function(){
  $('.sel_data').iCheck('uncheck'); 
});

$('#country_id').change(function(){
  var country_id = $(this).val();
  var state_id = $(this).data('state');
  $.ajax({
    url: base_url('states'),
    data:{country_id:country_id},
    dataType: 'Json',
    type: 'Post',
    success: function(result){
      var state_dropdown_class = ($('#state_cont').data('dropdown_class') == undefined || $('#state_cont').data('dropdown_class') == '')?'':$('#state_cont').data('dropdown_class');
      var function_name = $('#state_cont').data('function_name');
      var label = ($('#state_cont').data('label') == undefined || $('#state_cont').data('label') == '')?'':$('#state_cont').data('label');
      var data_attr = ($('#state_cont').data('attr') == undefined || $('#state_cont').data('attr') == '')?'':$('#state_cont').data('attr');

      var state_dropdown = '<div class="form-group">'+label+'<select class="'+state_dropdown_class+'" id="state_id" name="state_id" '+data_attr+'><option value="">Select State</option></select></div>';
      $('#state_cont').html(state_dropdown);
        $.each(result, function(index, item){
          var state_html = '<option value="'+item.id+'">'+item.name+'</option>';
          $('#state_id').append(state_html);
        });

      if (function_name != '' && function_name != undefined) {
        window[function_name]();
      }

      if (state_id != '') {
        $('#state_id').val(state_id).trigger('change');
      }
    }
  });
});

if ($('#country_id').val() != '') {
  $('#country_id').trigger('change');
}

$(document).on('change','#state_id',function(){
  var state_id = $(this).val();
  var city_id = $('#country_id').data('city');
  $.ajax({
    url: base_url('cities'),
    data:{state_id:state_id},
    dataType: 'Json',
    type: 'Post',
    success: function(result){
      var city_dropdown_class = ($('#city_cont').data('dropdown_class') == undefined || $('#city_cont').data('dropdown_class') == '')?'':$('#city_cont').data('dropdown_class');
      var function_name = $('#city_cont').data('function_name');
      var label = ($('#city_cont').data('label') == undefined || $('#city_cont').data('label') == '')?'':$('#city_cont').data('label');
      var data_attr = ($('#city_cont').data('attr') == undefined || $('#city_cont').data('attr') == '')?'':$('#city_cont').data('attr');

      var city_dropdown = '<div class="form-group">'+label+'<select class="'+city_dropdown_class+'" id="city_id" name="city_id" '+data_attr+'><option value="">Select City</option></select></div>';

      $('#city_cont').html(city_dropdown);
        $.each(result, function(index, item){
          var city_html = '<option value="'+item.id+'">'+item.name+'</option>';
          $('#city_id').append(city_html).trigger('change');
        });
      if (city_id != '') {
        $('#city_id').val(city_id);
      }

      if (function_name != '' && function_name != undefined) {
        window[function_name]();
      }
    }
  });
});

select2_start();

function select2_start(){
    $('.select2').select2({
      placeholder: function(){
        $(this).data('placeholder');
      }
    });
}

/* Datatable Starts */
  /* Pipeline Configuration Starts */
  //
// Pipelining function for DataTables. To be used to the `ajax` option of DataTables
//
$.fn.dataTable.pipeline = function ( opts ) {
    // Configuration options
    var conf = $.extend( {
        pages: 5,     // number of pages to cache
        url: '',      // script url
        data: null,   // function or object with parameters to send to the server
                      // matching how `ajax.data` works in DataTables
        method: 'GET' // Ajax HTTP method
    }, opts );
 
    // Private variables for storing the cache
    var cacheLower = -1;
    var cacheUpper = null;
    var cacheLastRequest = null;
    var cacheLastJson = null;
 
    return function ( request, drawCallback, settings ) {
        var ajax          = false;
        var requestStart  = request.start;
        var drawStart     = request.start;
        var requestLength = request.length;
        var requestEnd    = requestStart + requestLength;
         
        if ( settings.clearCache ) {
            // API requested that the cache be cleared
            ajax = true;
            settings.clearCache = false;
        }
        else if ( cacheLower < 0 || requestStart < cacheLower || requestEnd > cacheUpper ) {
            // outside cached data - need to make a request
            ajax = true;
        }
        else if ( JSON.stringify( request.order )   !== JSON.stringify( cacheLastRequest.order ) ||
                  JSON.stringify( request.columns ) !== JSON.stringify( cacheLastRequest.columns ) ||
                  JSON.stringify( request.search )  !== JSON.stringify( cacheLastRequest.search )
        ) {
            // properties changed (ordering, columns, searching)
            ajax = true;
        }
         
        // Store the request for checking next time around
        cacheLastRequest = $.extend( true, {}, request );
 
        if ( ajax ) {
            // Need data from the server
            if ( requestStart < cacheLower ) {
                requestStart = requestStart - (requestLength*(conf.pages-1));
 
                if ( requestStart < 0 ) {
                    requestStart = 0;
                }
            }
             
            cacheLower = requestStart;
            cacheUpper = requestStart + (requestLength * conf.pages);
 
            request.start = requestStart;
            request.length = requestLength*conf.pages;
 
            // Provide the same `data` options as DataTables.
            if ( typeof conf.data === 'function' ) {
                // As a function it is executed with the data object as an arg
                // for manipulation. If an object is returned, it is used as the
                // data object to submit
                var d = conf.data( request );
                if ( d ) {
                    $.extend( request, d );
                }
            }
            else if ( $.isPlainObject( conf.data ) ) {
                // As an object, the data given extends the default
                $.extend( request, conf.data );
            }
 
            settings.jqXHR = $.ajax( {
                "type":     conf.method,
                "url":      conf.url,
                "data":     request,
                "dataType": "json",
                "cache":    false,
                "success":  function ( json ) {
                    cacheLastJson = $.extend(true, {}, json);
 
                    if ( cacheLower != drawStart ) {
                        json.data.splice( 0, drawStart-cacheLower );
                    }
                    if ( requestLength >= -1 ) {
                        json.data.splice( requestLength, json.data.length );
                    }
                     
                    drawCallback( json );
                }
            } );
        }
        else {
            json = $.extend( true, {}, cacheLastJson );
            json.draw = request.draw; // Update the echo for each response
            json.data.splice( 0, requestStart-cacheLower );
            json.data.splice( requestLength, json.data.length );
 
            drawCallback(json);
        }
    }
};
 
// Register an API method that will empty the pipelined data, forcing an Ajax
// fetch on the next draw (i.e. `table.clearPipeline().draw()`)
$.fn.dataTable.Api.register( 'clearPipeline()', function () {
    return this.iterator( 'table', function ( settings ) {
        settings.clearCache = true;
    } );
} );
  /* Pipeline Configuration Starts */
/* Datatable Ends */

$('#example2').DataTable({
  "bProcessing": true,
  "bServerSide": true,
  "sServerMethod": "POST",
  "sAjaxSource": base_url('fetch_users_ajax'),
  
  
  "iDisplayLength": 10,
  "aoColumns": [
    { mData: 'fullname' } ,
    { mData: 'email' },
    { mData: 'mobile_no' },
    { mData: 'status'}
  ],

  // "sPaginationType":"full_numbers",
  // "iDisplayLength": 5
});

// var datatable = $('#example2').DataTable({
//     "processing": true,
//     "serverSide": true,
//     "ajax": {
//         url: base_url('fetch_users_ajax'),
//         type: 'POST'
//     },
//     "columns": [
//         {"data": "fullname"},
//         {"data": "email"},
//         {"data": "mobile_no"}
//     ],
// });