$('#type').change(function(){
	if ($(this).val() != '') {
		var has_bed = $(this).find(":selected").data("bed");
		var function_name = $('#beds').data('function_name');
		var new_class = ($('#beds').data('class') != '' && $('#beds').data('class') != undefined)?$('#beds').data('class'):'';
		var dropdown_class = ($('#beds').data('dropdown_class') != '' && $('#beds').data('dropdown_class') != undefined)?$('#beds').data('dropdown_class'):'';
		var label = ($('#beds').data('label') != '' && $('#beds').data('label') != undefined)?$('#beds').data('label'):'';
		var selected_bed = $('#beds').data('bed');
		if (has_bed == '1') {
			var html = '<div class="form-group">'+label+'<select name="beds" id="beds_option" class="'+dropdown_class+'"></select></div>';
			$('#beds').html(html).addClass(new_class);
			var beds = '<option value="">Beds</option><option value="0">None</option>';
			for (var i = 1; i <= 20; i++) {
				beds += "<option value='"+i+"'>"+i+"</option>"; 
			}
			$('#beds_option').html(beds);
			(selected_bed != '' && selected_bed != undefined)?$('#beds_option').val(selected_bed):'';
		}
		else{
			$('#beds').removeClass(new_class).empty();
		}

		if (function_name != '' && function_name != undefined) {
		   		window[function_name]();
		}
	}
});

$('#map').keyup(function(){
	$('#property_map_cont').html($(this).val());
});

$('#status').change(function(){
	if ($(this).val() == 'Rent' || $(this).val() == 'PG') {
		$('#rent').show();
		$('#sell').hide();
	}
	else{
		$('#sell').show();
		$('#rent').hide();
	}
});

$('#status, #type').trigger('change');
$('#map').trigger('keyup');

$("#form-map").validate({
  ignore: [],
  rules: {
    status: "required",
    country_id: "required",
    state_id: "required",
    city_id: "required",
    
  }
});

$('.user_contact').click(function(){
 var UserName = $('#form-contact-agent-name').val();
 var UserEmail = $('#form-contact-agent-email').val();
 var UserMobile = $('#mobile_no').val();
 var agent_id = $('#contact_agent_id').val();
$.ajax({
 	type:'POST',
 	url:base_url('ajax_contact_details'),
 	dataType:'JSON',
 	data:({UserName:UserName,UserEmail:UserEmail,UserMobile:UserMobile,agent_id:agent_id}),
 	success:function(data){
 		var html = '<p>'+data.email+'</p><p>'+data.mobile_no+'</p>';
 		$('#agent_details').html(html);
 	}
})

});

$(document).on('change','#form-map select',function(){
	var label = $(this).attr('name');
	$("label[for='"+label+"']").remove();
});