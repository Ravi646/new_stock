$(document).ready(function(){
$('.verify_user').click(function(e){
        // pageURL = $(location).attr("href");
        var active = $('.user_status').is(":checked")?1:0;
        var user_id = $('.user_status').data('user_id');
        $.ajax({
                type:'POST',
                url:base_url('verification-status'),
                data:({active:active,id:user_id }),
                success: function(data) {
                    alert('successfully verified');
                }
               });
     
});
    });
   
 