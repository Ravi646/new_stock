<main>
<div class="container">
  <input class="accord" id="tab1" type="radio" name="tabs" checked>
  <label for="tab1" >Individual</label>
  <input class="accord" id="tab2" type="radio" name="tabs">
  <label for="tab2">Agent</label>
 <input class="accord" id="tab3" type="radio" name="tabs">
  <label for="tab3">Builder</label>
  <?php $order_type = in_array(1,array_column($pakages,'order_type_id'));
  if($order_type == 1){  ?>
   <section id="content1">
     <table class="pack-table">
      <tr class="ind-head">
      <td style="background:#db343f;">
          Benefits
      </td>
     <?php for ($i=0; $i <count($pakages); $i++) { 
      if($pakages[$i]['order_type_id'] == '1') {  ?>
      <td style="background:<?php echo $pakages[$i]['background_color'] ?>;">
      <?php echo $pakages[$i]['pakages_type']; ?>
        </td>
      <?php  } } ?>
      </tr>     
      <tr class="ind-content">
      <td>
         Validity
      </td>
      <?php for ($j=0; $j <count($pakages) ; $j++) {
      if($pakages[$j]['order_type_id'] == '1') { ?>  
      <td>
         <?php echo $pakages[$j]['validity']; ?>
        </td>
       <?php  } }?>
     </tr>
       <?php for ($k=0; $k <count($benefits_type); $k++) { ?>
       <tr class="ind-content">
        <td>
        <?php echo $benefits_type[$k]['benefits_type']; ?> 
        </td>
       <?php for ($l=0; $l<count($pakages); $l++) { 
          if($pakages[$l]['order_type_id'] == '1') {  
          $benefits_type_id = array_column($pakages[$l]['benefits_type'],'benefits_type_id');      ?>
          <td>
            <?php echo (in_array($benefits_type[$k]['benefits_type_id'],$benefits_type_id))?'<i class="fa fa-check" aria-hidden="true">':'<i class="fa fa-minus" aria-hidden="true">';?>
          </td>
      <?php } }?>
    </tr>
    <?php } ?>
   <tr class="ind-buy">
      <td>
        </td>
     <?php for ($m=0; $m <count($pakages) ; $m++) {
      if($pakages[$m]['order_type_id'] == '1'){
      ?>
        <td>
         <a class="buy-button btn btn-info" href ="<?php echo base_url('pakages-details/'.$pakages[$m]['pakages_type_id'])?>" >Buy</a>
        </td>
       <?php } } ?>
     </tr>
    </table>
     </section>
    <?php }  
    $order_second_type = in_array(2,array_column($pakages,'order_type_id')); 
    if($order_second_type == 1){
    ?>
    <section id="content2">
      <!-- <div class="col-sm-12"> -->
      <div class="content-sct">
      <div class="row">
      <?php 
      for ($n=0; $n <count($pakages) ; $n++) { 
       if($pakages[$n]['order_type_id'] == '2'){ ?>
       
         <div class="col-sm-3 item">
        <h4 class="item-head"><?php echo $pakages[$n]['pakages_type'] ?></h4>
        <p class="item-content">
          <p class="item-cat">Benefits:</p>
          <ul class="item-list">
            <?php echo $pakages[$n]['pakages_details']  ?>
          </ul>
           </p>
           <a class="buy-button btn btn-info" href ="<?php echo base_url('pakages-details/'.$pakages[$n]['pakages_type_id'])?>" data-pakages_id = '<?php echo $pakages[$n]['pakages_type_id']?>' >BUY NOW</a>
      </div>
    <?php } } ?>
</div>
</div>
</section>
<?php
  } 
    $order_third_type = in_array(3,array_column($pakages,'order_type_id')); 
    if($order_third_type == 1){
?>
    <section id="content3">
    <!-- <div class="col-sm-12"> -->
      <div class="content-sct">
      <div class="row">
      <?php for ($o=0; $o<count($pakages) ; $o++) { 
      if($pakages[$o]['order_type_id'] == '3'){
      ?>
     <div class="col-sm-3 item">
        <h4 class="item-head"><?php echo $pakages[$o]['pakages_type'] ?></h4>
        <p class="item-content">
          <p class="item-cat">Benefits :</p>
          <ul class="item-list">
            <?php echo $pakages[$o]['pakages_details'] ?>
          </ul>
          </p>
        <a class="buy-button" href ="<?php echo base_url('pakages-details/'.$pakages[$o]['pakages_type_id'])?>" data-pakages_id="<?php echo $pakages[$o]['pakages_type_id'] ?>" >BUY NOW</a>
        </div>
    <?php  } 
  } ?>
   </div>
</div>
     <!-- </div> -->
</section>
<?php } ?>
 <div class="col-sm-3 bucket">
        <h3 style="border-bottom: 1px dotted;">MY ORDERS <div class="orderNo" id="totalItemsOrdered"><?php echo $cart_count ?></div></h3>
        <a class="goto-cart" data-pakages_type_id="4" >GO TO CART</a>
      </div>
    <div class="col-sm-3 talk-expert">
        <h5 style="border-bottom: 1px dotted;background: #c4c4c4;font-weight: 600;padding: 10px 8px;">Talk To Experts | +91 7666405482</h5>
        <div class="callback-form">
        <h4 style="color: #1950a4;">Request a Callback</h4>
      <form id="callback">
          <input type="text" class="user_name" name="user_name" placeholder="Name*" required=""><br>
          <?php echo form_error('user_name') ?>
         <input type="text" class="user_mobile" name="user_mobile" placeholder="Mobile*" required=""><br>
          <?php echo form_error('user_mobile') ?>
         <input type="email" class="user_email" name="user_email" placeholder="Email (Optional)"><br>
          <?php echo form_error('user_email') ?>
         <input type="text" class="user_city" name="user_city" placeholder="City"><br>
          <?php echo form_error('user_city') ?>
          <textarea class="user_message" name="user_message" placeholder="Message*" required=""></textarea><br>
          <?php echo form_error('user_message') ?>
          <button class="callback-btn" type="button" >GET A CALLBACK</button>
        </form>
        </div>
    </div>
</main>

  <!--==============================================================================================-->



  <!--==============================================================================================-->
    
  
