<main>
  <div class="container">
<center>
	<img src="<?php echo base_url('assets/legal_services/img/order-confirmed.png') ?>" alt="" class="img-fluid">
</center>
  
  <section id="content1">
    <div class="col-sm-9 details">
      
      
        <div class="d-head"><h3>ORDER DETAILS</h3></div>
        <div class="d-content">
          <ul class="order_details">
            <li style="list-style:none;"><h4>Order Id: <?php echo $final_checkout_data['order_id']?></h4></li>
            <li style="list-style:none;"><h4>Total Amount : <?php echo $final_checkout_data['final_amount']?>/-</h4></li>
           <!--  <li style="list-style:none;height: 30px;"><h4 style="float: left;">Package : BASIC</h4><span><a class="buy-button" href="">Package Details</a></span></li>
            
            <li style="list-style:none;"><h4>Validity : 1 YEAR</h4></li> -->
          </ul>
        </div>
        <div class="d-foot">
          <!-- <p>Total Amount Payable</p> -->
        </div>
        <span><a class="buy-button" href="<?php echo base_url('legal-services') ?>" >CLICK HERE TO PURCHASE MORE</a></span>

    </div>
    <<!-- div class="col-sm-3 bucket">
        <h3 style="border-bottom: 1px dotted;">MY ORDERS <div class="orderNo" id="totalItemsOrdered"><?php echo count($this->cart->contents()) ?></div></h3>
        <a class="goto-cart" data-pakages_type_id="4" >GO TO CART</a>
      </div> -->
    <div class="col-sm-3 talk-expert">
        <h5 style="border-bottom: 1px dotted;background: #c4c4c4;font-weight: 600;padding: 10px 8px;">Talk To Experts | +91 7666405482</h5>
        <div class="callback-form">
        <h4 style="color: #1950a4;">Request a Callback</h4>
      <form id="callback">
          <input type="text" class="user_name" name="user_name" placeholder="Name*" required=""><br>
          <?php echo form_error('user_name') ?>
         <input type="text" class="user_mobile" name="user_mobile" placeholder="Mobile*" required=""><br>
          <?php echo form_error('user_mobile') ?>
         <input type="email" class="user_email" name="user_email" placeholder="Email (Optional)"><br>
          <?php echo form_error('user_email') ?>
         <input type="text" class="user_city" name="user_city" placeholder="City"><br>
          <?php echo form_error('user_city') ?>
          <textarea class="user_message" name="user_message" placeholder="Message*" required=""></textarea><br>
          <?php echo form_error('user_message') ?>
          <button class="callback-btn" type="button" >GET A CALLBACK</button>
        </form>
        </div>
    </div>
</section>
</div>
</main>