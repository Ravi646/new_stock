<?php $userdata = $this->session->userdata('userdata'); 
?>
<main>
  <div class="container">
  
  <!-- 
  <input class="accord" id="tab1" type="radio" name="tabs" checked>
  <label for="tab1">Individual</label> -->

    <section id="content1">
       <?php if(count($saved_cart)>0){
       if(array_filter($saved_cart)){ ?>
   
       <?php for ($i=0;$i<count($saved_cart);$i++) { 
              if(!empty($saved_cart[$i])){ ?>
      <div class="panel panel-danger">
      <div class="panel-heading"><?php echo 'you have already purchased&nbsp&nbsp'.$saved_cart[$i]['pakages_type'].'&nbsp&nbspRemove this item to purchase other pakages'; ?></div>
    </div>
  <?php } 
  } 
 }
}?>
  
      <div class="col-sm-9 details payment">
          <div class="d-head">
          <p class="dhead-lft">MY CART ( <?php echo $this->cart->total_items(); ?> ITEMS)</p><p class="dhead-rght">TOTAL PAYMENT AMOUNT:₹ <?php echo $this->cart->total(); ?></p></div>
        <div class="d-content">
            <div class="col-md-12">
              <div class="col-sm-3"><b>Product</b></div>
              <div class="col-sm-9">
                <div class="col-sm-2 sm-cont"><b>Qty</b></div>
                <div class="col-sm-2 sm-cont"><b>Remove</b></div>
                <div class="col-sm-2 sm-cont"><b>Price</b></div>
                <div class="col-sm-2 sm-cont"><b>Discount</b></div>
                <div class="col-sm-4 sm-cont"><b>Total Amount</b></div>
              </div>
            </div>
          <?php $i = 1;
            foreach ($this->cart->contents() as $item) { ?>
          <div class="col-md-12 pakages">
            <div class="col-sm-3"><p><?php echo $item['name']; ?></p></div>
            <div class="col-sm-9">
              <div class="col-sm-2 sm-cont">Qty<input class="qty qty_update" data-rowid="<?php echo $item['rowid'] ?>" value="<?php echo $item['qty'] ?>" data-order_id="<?php echo $item['id'] ?>" type="text" name="qty"></div>
              <div class="col-sm-2 sm-cont"><a class="remove_cart_item" data-item_row_id="<?php echo $item['rowid'] ?>" ><i class="fa fa-trash"></i></a></div>
              <div class="col-sm-2 sm-cont final_price" >₹ <?php echo $item['options']['final_price'];?></div>
              <div class="col-sm-2 sm-cont" >₹ <?php echo $item['options']['discounted_price'] ?></div>
              <div class="col-sm-4 sm-cont real_price">₹ <?php echo $item['subtotal']?> </div>
            </div>
             </div>
            <?php } ?>
          <!-- <span style="border-left: 2px dotted #b2b2b2;padding: 20px;">Qty<input type="text" name="qty"></span><span style="border-left: 2px dotted #b2b2b2;padding: 20px;">Delete</span><span style="border-left: 2px dotted #b2b2b2;padding: 20px;">RS2500</span> -->
        </div> 
        <div class="d-foot d-foot-cont">
          <div class="col-md-12 ">
            <div class="col-sm-6">
          <input type="text" name="coupon"><input type="submit" name="submit" value="APPLY"><br><br>COUPON APPLIED:</div>
          <div class="col-sm-6 sub_total">Sub Total:&nbsp&nbsp₹ <?php echo $this->cart->total(); ?></div>
        </div>
     </div>
        <span><a class="sh-button-lg" href="<?php echo base_url('legal-services')?>" >Continue Shopping</a></span>
        <span><button type="button" <?php if(count($saved_cart)>0){ echo (!array_filter($saved_cart))?'':'disabled'; } ?> class="buy-button-lg proceed_payment" data-user_checkout_id="<?php echo $userdata['user_id'] ?>" >Proceed To Payment</button></span>

    </div>
    
      <div class="col-sm-3 bucket">
        <h3 style="border-bottom: 1px dotted;">NEED HELP?</h3>
        <P>Call Us: +91 7666405482</P>
      </div>

      <div class="col-sm-3 talk-expert">
        <h5 style="border-bottom: 1px dotted;background: #c4c4c4;font-weight: 600;padding: 10px 8px;">We Support Secure Payment Methods</h5>
        <img src="<?php echo base_url('assets/legal_services/img/payment.jpg') ?>" width="250px">
       
      </div>
  </section>
    <!--==============================================================================================-->
 <!--==============================================================================================-->
    </div>
    <div class="modal fade" id="quantity_change" tabindex="-1" role="dialog" aria-labelledby="loginModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-body">
     <div class="form-group has-feedback">
       <h5>Quantity Updated Successfully</h5>
      </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
     </div>
    </div>
  </div>
</div>
 <div class="modal fade remove_item" id="remove_item" tabindex="-1" role="dialog" aria-labelledby="loginModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-body">
     <div class="form-group has-feedback">
       <h5>Item Removed Successfully</h5>
      </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
     </div>
    </div>
  </div>
</div>
<div class="modal fade" id="present_items" tabindex="-1" role="dialog" aria-labelledby="loginModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-body">
     <div class="form-group has-feedback">
       <h5>NO ITEM IN THE CART</h5>
      </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
     </div>
    </div>
  </div>
</div>

</main>
  