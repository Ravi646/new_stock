<div class="row">
	<div class="col-md-12">
		<div class="box box-primary">
			<div class="box-header with-border">
				<h3 class="box-title">ORDERS</h3>
			</div>
			<div class="box-body">
				<table class="table table-bordered">
					<thead>
						<th>User Type</th>
						<th>Order ID</th>
						<th>Order Status</th>
						<th>Pakage</th>
						<th>Price</th>
						<th>discount Amount</th>
						<th>Final Amount</th>
						<th>Payment Status</th>
						<th>Qty</th>
						<th>User Details</th>
						<th>Validity</th>
						<th>Action</th>
					</thead>
					<tbody>
						<?php for ($i=0; $i <count($fetch_all_orders); $i++) {  ?>
							<tr>
						  	<td><?php echo $fetch_all_orders[$i]['order_type']; ?></td>
						  	<td><?php echo $fetch_all_orders[$i]['unique_order_id']; ?></td>
						  	<td><?php echo $fetch_all_orders[$i]['order_status']; ?></td>
						  	<td><?php echo $fetch_all_orders[$i]['pakages_type']; ?></td>
						  	<td><?php echo $fetch_all_orders[$i]['actual_price']; ?></td>
							<td><?php echo$fetch_all_orders[$i]['discount_price']?></td>
							<td><?php echo$fetch_all_orders[$i]['price_after_discount']?></td>
							<td><?php echo $fetch_all_orders[$i]['payment_status'] ; ?></td>
							<td><?php echo $fetch_all_orders[$i]['quantity_ordered'] ; ?></td>
							<td ><a class="btn btn-info"   data-toggle="popover" data-container="body" data-placement="left" type="button" data-html="true" >User Details</a></td>
							<td><?php echo $fetch_all_orders[$i]['validity'] ?></td>
						   <td>
						   	<a href="<?php echo base_url('manage-order/'.$fetch_all_orders[$i]['order_id']); ?>"><i class="fa fa-trash"></i></a>
							</td>
						  </tr>
						  <div id="popover-content" class="hide">
						  	<li>Name: <?php echo ($fetch_all_orders[$i]['fname'] != '')?$fetch_all_orders[$i]['fname'].$fetch_all_orders[$i]['lname']:(($fetch_all_orders[$i]['agency_name'] != '')?$fetch_all_orders[$i]['agency_name']:$fetch_all_orders[$i]['firm_name']) ;?></li>
						  	<li>UserType: <?php echo $fetch_all_orders[$i]['user_type']?></li>
						  	<?php if($fetch_all_orders[$i]['email'] != ''){?>
						  	<li>Email: <?php echo $fetch_all_orders[$i]['email'] ?></li>
						  	<?php } ?>
						  	<?php if($fetch_all_orders[$i]['mobile_no'] != ''){?>
						  	<?php } ?>
						  	<li>Mobile No: <?php echo $fetch_all_orders[$i]['mobile_no'] ?></li>
						  </div>
						<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
