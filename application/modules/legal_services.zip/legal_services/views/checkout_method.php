<main>
  <div class="container">
  <!-- 
  <input class="accord" id="tab1" type="radio" name="tabs" checked>
  <label for="tab1">Individual</label> -->
     <section id="content1">
    <div class="col-sm-9 details payment">
      <?php echo form_open() ;?>
      <div class="d-content">
          <div class="col-md-8">
            <h3>ORDER ID:<?php echo $order_id ;?></h3>
          </div>
          <div class="col-md-4">
            <h3>Total Amount:&nbsp&nbsp₹<?php echo $this->cart->total();?></h3>
            <input type="hidden" name="final_amount" value="<?php echo $this->cart->total()?>">
            <input type="hidden" name="unique_order_id" value="<?php echo $order_id ?>">
          </div>
        <div class="col-md-12">
            <h4>Choose Payment Option</h4>
          </div>
         <div class="payment-gateway">
              <div class="col-sm-12 item-row">
                <?php for ($i=0; $i <count($fetch_payment_type) ; $i++) { ?>
                <div class="col-sm-3">
                  <input type="radio" name="payment_type" value="<?php echo $fetch_payment_type[$i]['payment_type_id'] ?>"> <img src="<?php echo base_url($fetch_payment_type[$i]['payment_logo']) ?>"><br><?php echo $fetch_payment_type[$i]['payment_type'] ?>
                  </div>
              <?php   } ?>
              </div>
              <button type="submit" class="buy-button-lg ">Proceed to Payment</button>
           <?php echo form_close() ;?>
           </div>
         </div>
        </div>
      <!-- </div> -->
    <!-- </div> -->
          <div class="col-sm-3 bucket">
        <h3 style="border-bottom: 1px dotted;">NEED HELP?</h3>
        <P>Call Us: +91 7666405482</P>
      </div>

      <div class="col-sm-3 talk-expert">
        <h5 style="border-bottom: 1px dotted;background: #c4c4c4;font-weight: 600;padding: 10px 8px;">We Support Secure Payment Methods</h5>
        <img src="<?php echo base_url('assets/legal_services/img/payment.jpg') ?>" width="250px">
       
      </div>

  </section>
    
  
  <!--==============================================================================================-->



  <!--==============================================================================================-->
    
  </div>  
</main>
  
  

</body>

</html>
