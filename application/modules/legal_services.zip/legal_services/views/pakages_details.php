<main>
 <div class="container">
  <!-- 
  <input class="accord" id="tab1" type="radio" name="tabs" checked>
  <label for="tab1">Individual</label> -->
    <section id="content1">
    <div class="col-sm-9 details">
      <div class="d-head"><p><?php echo $fetch_pakage_details['pakages_type']?></p></div>
        <div class="d-content">
          <ul>
            <?php echo $fetch_pakage_details['pakages_details'] ?>
          </ul>
        </div>
        <div class="d-foot">
          <p>Total Amount Payable</p>
          <p><?php echo '₹'.$fetch_pakage_details['pakages_price'] ?></p>
        </div>
        <span><a class="buy-button order_cart" data-pakages_id="<?php echo $fetch_pakage_details['pakages_type_id'] ?>" data-order_type_id="<?php echo $fetch_pakage_details['order_type_id'] ?>">ADD TO MY ORDERS</a></span>

    </div>
    
     <div class="col-sm-3 bucket">
        <h3 style="border-bottom: 1px dotted;">MY ORDERS <div class="orderNo" id="totalItemsOrdered"><?php echo count($this->cart->contents()); ?></div></h3>
        <a class="goto-cart" data-pakages_type_id="4" >GO TO CART</a>
    </div>

      <div class="col-sm-3 talk-expert">
        <h5 style="border-bottom: 1px dotted;background: #c4c4c4;font-weight: 600;padding: 10px 8px;">Talk To Experts | +91 7666405482</h5>
        <h4 style="color: #1950a4;">Request a Callback</h4>
        <form action="#">
          <input type="text" name="name" placeholder="Name"><br>
          <input type="text" name="mobile" placeholder="Mobile"><br>
          <input type="email" name="email" placeholder="Email"><br>
          <input type="text" name="city" placeholder="City"><br>
          <textarea name="message" placeholder="Message"></textarea><br>
          <input id="callback-btn"type="submit" name="submit" value="GET A CALLBACK">
        </form>
      </div> 
  </section>
    
  
  <!--==============================================================================================-->



  <!--==============================================================================================-->
    
  </div>
  <div class="modal fade" id="add_cart" tabindex="-1" role="dialog" aria-labelledby="loginModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-body">
     <div class="form-group has-feedback">
       <h5>Added to Cart Successfully</h5>
      </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
     </div>
    </div>
  </div>
</div>  
</main>
  