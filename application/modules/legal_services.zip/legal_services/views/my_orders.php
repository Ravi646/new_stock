<div class="row">
	<div class="col-md-12">
		<div class="box box-primary">
			<div class="box-header with-border">
				<h3 class="box-title">MY ORDERS</h3>
			</div>
			<div class="box-body">
				<table class="table table-bordered">
					<thead>
						<th>Order ID</th>
						<th>Pakage Type</th>
						<th>Pakage</th>
						<th>Price</th>
						<th>discount Amount</th>
						<th>Final Amount</th>
						<th>Qty</th>
					    <th>Validity</th>
						<th>Action</th>
					</thead>
					<tbody>
						<?php for ($i=0; $i <count($fetch_user_placed_orders); $i++) {  ?>
							<tr>
						  	<td><?php echo $fetch_user_placed_orders[$i]['unique_order_id']; ?></td>
						  	<td><?php echo $fetch_user_placed_orders[$i]['order_type']; ?></td>
						  	<td><?php echo $fetch_user_placed_orders[$i]['pakages_type']; ?></td>
						  	<td><?php echo $fetch_user_placed_orders[$i]['actual_price']; ?></td>
							<td><?php echo$fetch_user_placed_orders[$i]['discount_price']?></td>
							<td><?php echo$fetch_user_placed_orders[$i]['price_after_discount']?></td>
							
							<td><?php echo $fetch_user_placed_orders[$i]['quantity_ordered'] ; ?></td>
							<td><?php echo $fetch_user_placed_orders[$i]['validity'] ?></td>
						   <td>
						   	<a href="<?php echo base_url('manage-order/'.$fetch_user_placed_orders[$i]['order_id']); ?>"><i class="fa fa-trash"></i></a>
							</td>
						  </tr>
						 <?php } ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
