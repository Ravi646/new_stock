<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Pakages_model extends CI_Model {
	public function __construct(){
	        parent::__construct(); 
	}
	public function fetch_user_pakages(){
		$query = $this->db->get('pakages_type_master')
						  ->result_array();

		for ($i=0; $i <count($query) ; $i++) { 
		if($query[$i]['benefits_type_id'] != ''){
			$benefits_type = explode(',',$query[$i]['benefits_type_id']);
			$query[$i]['benefits_type'] = $this->fetch_benefits_type($benefits_type);
		}
		}
		return $query;
	}
	// public function fetch_pakages_type($pakages_type_id){
	// 	$query =$this->db->where_in('pakages_type_id',$pakages_type_id)
	// 	                 ->get('pakages_type_master')
	// 				     ->result_array();
	//     return $query;
	// }
	public function fetch_benefits_type($benefits){
		$query = $this->db->where_in('benefits_type_id',$benefits)
						  ->get('benefits_master')
						  ->result_array();

		return $query;
}
	public function fetch_full_benefits(){
		$query = $this->db->where('order_type_id',1)
						  ->get('benefits_master')
						  ->result_array();
	    return $query;
	}
	public function fetch_pakage_details($pakages_type_id){
		$query = $this->db->where('pakages_type_id',$pakages_type_id)
						  ->get('pakages_type_master')
						  ->row_array();
		return $query;
	}
	public function insert_order($userdata){
			foreach ($this->cart->contents() as $item){
            $order_data = array(
							'order_type_id'     => $item['options']['order_type_id'],
							'cart_row_id'       => $item['rowid'],
							'order_status'      => 'None',
						    'payment_status'    => 'added to cart',
						    'actual_price'      => $item['options']['final_price'],
							'discount_price'    => $item['options']['discounted_price'],
							'price_after_discount' => $item['price'],
						    'total_amount'      => $item['subtotal'],
						    'pakages_type_id'   => $item['id'],
						    'user_id'           => $userdata['user_id'],
						    'email'             => $userdata['email'],
						    'mobile_no'         => $userdata['mobile_no'],
							'refund_status'     => 'None',
							'ordered_date'      => date('Y-m-d'),
							'quantity_ordered'  => $item['qty']
						);
       $return_result = $this->db->select('pakages_type_id')
        					  ->from('order_master')
        					  ->where('pakages_type_id',$item['id'])
        					  ->where('user_id',$userdata['user_id'])
        					  ->where('order_status !=','Placed')
        					  ->get()
        					  ->row_array();
        if(count($return_result)>0){
        	$this->db->update('order_master',$order_data,array('pakages_type_id' => $item['id'],'user_id' => $userdata['user_id']));
        	$msg = 'success';
        }else{
        $placed_order = $this->db->select('pakages_type_id')
        					  ->from('order_master')
        					  ->where('pakages_type_id',$item['id'])
        					  ->where('user_id',$userdata['user_id'])
        					  ->where('order_status','Placed')
        					  ->get()
        					  ->row_array();
        if(count($placed_order)>0){
        	$msg = 'fail';
        }else{
		$this->db->insert('order_master',$order_data);
			$msg = 'success';
        }
		}  
        }
        return $msg;
		}
	public function fetch_cart_order($user_id){
		$query = $this->db->select('*')
						  ->from('order_master')
						  ->where('user_id',$user_id)
						  ->where('order_status !=','Placed')
						  ->get()
						  ->result_array();
		return $query;

	}
	public function fetch_user_cart_order($user_id){
		$query = $this->db->select('*')
						  ->from('order_master')
						  ->where('user_id',$user_id)
						  ->where('order_status !=','Placed')
						  ->get();
		$query = $query->result_array();
		for ($i=0; $i <count($query); $i++) { 
		$query[$i]['pakages_type'] = $this->fetch_user_pakages_type($query[$i]['pakages_type_id']);
		}
		return $query;				  
}
	public function fetch_user_pakages_type($pakages_type_id){
		$query = $this->db->select('pakages_type,pakages_details')
				 ->from('pakages_type_master')
				 ->where('pakages_type_id',$pakages_type_id)
				 ->get()
				 ->row_array();
		return $query;
}
	public function delete_order($row_id,$user_id){
       $this->db->delete('order_master', array('cart_row_id' =>$row_id ), array('user_id' => $user_id));
    }
    public function update_cart_quantity($prod_qty,$row_id,$user_id){
       $this->db->update('order_master',array('quantity_ordered' => $prod_qty),array('user_id' => $user_id,'cart_row_id',$row_id));
    }
    public function insert_order_id($user_id,$order_id){
       $this->db->update('order_master',array('unique_order_id' => $order_id),array('user_id' => $user_id));
    }
    public function save_update_order_data($order_data,$user_id){
    	$this->db->update('order_master',$order_data,array('user_id' => $user_id));
    }
    public function fetch_payment_type(){
    	$query = $this->db->get('payment_type_master')
    					  ->result_array();
    	return $query;
    }
    public function fetch_placed_pakages(){
    	if(count($this->cart->contents())>0){
    	foreach ($this->cart->contents() as $item) {
    	$query[] = $this->db->select('OM.order_id,OM.pakages_type_id,PTM.pakages_type as pakages_type')
    						->join('pakages_type_master PTM','PTM.pakages_type_id = OM.pakages_type_id','left')
    					    ->where('OM.pakages_type_id',$item['id'])
    					    ->where('OM.order_status','Placed')
							->get('order_master OM')
    					    ->row_array();
		}
		return $query;
	}
    }
    public function fetch_all_orders($user_id){
    	if($user_id == 1){
    		$query = $this->db->select('OM.*,OTM.order_type as order_type,PTM.pakages_type as pakages_type,PTM.validity as validity,PMT.payment_type as payment_type,UM.fname as fname,UM.lname as lname,UM.firm_name as firm_name,UM.agency_name as agency_name,UM.user_type,UTM.user_type as user_type')
    		     			  ->join('order_type_master OTM','OTM.order_type_id = OM.order_type_id','left')
    		     			  ->join('pakages_type_master PTM','PTM.pakages_type_id = OM.pakages_type_id','left')
    		     			  ->join('payment_type_master PMT','PMT.payment_type_id = OM.payment_type_id','left')
    		     			  ->join('user_master UM','UM.user_id = OM.user_id','left')
    		     			  ->join('user_type_master UTM','UTM.user_type_id = UM.user_type','left') 
    		     			  ->get('order_master OM')
  							  ->result_array();
    		return $query;
    	}
    }
    public function delete_user_order($order_id){
    	$this->db->delete('order_master',array('order_id' => $order_id));
    }
    public function fetch_user_placed_orders($user_id){
    	$query = $this->db->select('OM.*,OTM.order_type as order_type,PTM.pakages_type as pakages_type,PTM.validity as validity')
    		     			  ->join('order_type_master OTM','OTM.order_type_id = OM.order_type_id','left')
    		     			  ->join('pakages_type_master PTM','PTM.pakages_type_id = OM.pakages_type_id','left')
    		     			  ->where('user_id',$user_id)
    		     			  ->where('order_status','Placed')
    		     			  ->get('order_master OM')
  							  ->result_array();
    		return $query;
    }
    public function callback_form_details($user_callback_form){
		$this->db->insert('package_user_contact',$user_callback_form);
		if($this->db->error()['code'] == 0){
			$db_status = array(
				'status' => 'true',
				'msg' => 'Our Executive will Callback you.',
				'class' => 'panel-success'
			);
		}else{
			$db_status = array(
				'status' => 'false',
				'msg' => 'Please try again.',
				'class' => 'panel-success'
			);
		}
		return $db_status;


	}
}

