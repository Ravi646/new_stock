<?php
defined('BASEPATH') OR exit('No direct script access allowed');
    class Pakages_controller extends MX_Controller {
    	public function __construct(){
	        parent::__construct();
	        $this->load->model('pakages_model');
	        $this->load->helper('real_estate');
	        $this->load->library('cart');
	}
		public function pakages(){
			$userdata = $this->session->userdata('userdata');
			if(!empty($userdata)){
               $user_saved_cart = $this->pakages_model->fetch_user_cart_order($userdata['user_id']);
				
				if(count($user_saved_cart)>0){
				for ($h=0; $h<count($user_saved_cart) ;$h++) { 
					$cart_data[] = array(
		    			'id'  => $user_saved_cart[$h]['pakages_type_id'],
		    			'price' => $user_saved_cart[$h]['price_after_discount'],
		    			'qty' => $user_saved_cart[$h]['quantity_ordered'],
						'name' => $user_saved_cart[$h]['pakages_type']['pakages_type'],
		    			'options' => array(
		    			'pakages_details' => $user_saved_cart[$h]['pakages_type']['pakages_details'],
		    			'discounted_price' => $user_saved_cart[$h]['discount_price'],
						'final_price' => $user_saved_cart[$h]['actual_price'],
		    			'order_type_id' => $user_saved_cart[$h]['order_type_id']
		    	),
		    	    'rowid' => $user_saved_cart[$h]['cart_row_id']
);	
				}
			}
				if(count($cart_data)>0){
			        $cart_count = $this->cart->contents();
			        if(empty($cart_count)){
					$this->cart->insert($cart_data);
				}
				}
			}
			// if(!empty($userdata)){
			// 	$user_cart_count = $this->pakages_model->fetch_cart_order($userdata['user_id']);
			// }
			// echo "string";
			// exit();
			$data['add_bel_cust_js'] = base_url('assets/legal_services/js/legal_services.js');
			$data['add_bel_cust_css']  = base_url('assets/legal_services/css/style.css');
			$data['pakages'] = $this->pakages_model->fetch_user_pakages();
			$data['benefits_type'] = $this->pakages_model->fetch_full_benefits();
			$data['cart_count'] = count($this->cart->contents());
            // if(isset($user_cart_count)){
            // 	$data['user_cart_count'] = count($user_cart_count);
            // }
			// echo "<pre>";
			// print_r($data['pakages']);
			// echo "</pre>";
			$this->load->front_view('pakages',$data);
		}
		public function pakages_details($pakages_id){
		// $userdata = $this->session->userdata('userdata');
		// 	if(!empty($userdata)){
		// 		$user_cart_count = $this->pakages_model->fetch_cart_order($userdata['user_id']);
		// 	}
			// $pakages_type_id = $this->input->post('pakages_id');
		$data['fetch_pakage_details'] = $this->pakages_model->fetch_pakage_details($pakages_id);
		$data['add_bel_cust_css']  = base_url('assets/legal_services/css/pakage_details.css');
		$data['add_bel_cust_js']  = base_url('assets/legal_services/js/legal_services.js');
		// $data['cart_count'] = count($this->cart->contents());
			$this->load->front_view('pakages_details',$data);
		}
		public function pakages_cart(){
			$userdata = $this->session->userdata('userdata');
		    $product_id = $this->input->post('pakages_id');
		    $order_type_id = $this->input->post('order_type_id');
		    // print_r($order_type_id);
		    $product_details = $this->pakages_model->fetch_pakage_details($product_id);
			if(count($product_details)>0){
				$discounted_price = ($product_details['discounted_price'] != '' || $product_details['discounted_price'] != 0)?$product_details['pakages_price'] - $product_details['discounted_price']:0;
				$discount_percent = ($product_details['discount_percent'] != '' || $product_details['discount_percent'] != 0)?$pakages_details['pakages_price'] * $product_details['discount_percent']/100:0;
		    	$final_price = ($discounted_price != 0)?$discounted_price:(($discount_percent != '')?$discount_percent:$product_details['pakages_price']);
		    	$cart_data = array(
		    	'id'  => $product_details['pakages_type_id'],
		    	'price' => $final_price,
		    	'qty' => $product_details['qty'],
				'name' => $product_details['pakages_type'],
		    	'options' => array(
		    	'pakages_details' => $product_details['pakages_details'],
		    	'discounted_price' => ($product_details['discounted_price'] != '')?$product_details['discounted_price']:0,
				'final_price' => $product_details['pakages_price'],
		    	'order_type_id' => $order_type_id
		    	),
);	
		    	$this->cart->insert($cart_data);
				$response = count($this->cart->contents());
		    	}else{
		    	$response = 'unable to add to cart';
		    	}
				echo $response;
		    }
	    public function cart_items(){
				$userdata = $this->session->userdata('userdata');
	    		$pakages_id = $this->input->post('pakages_id');
			if(empty($userdata)){
				$response['attr'] = 'false';
	    		$response['redirect'] = base_url('user-login/'.$pakages_id);
	    	}else{
	    		$response['attr'] = 'True';
	    		$response['redirect'] = base_url('view-cart/'.$pakages_id);
	    		$responce['msg'] = $this->pakages_model->insert_order($userdata);
			}
	    	echo json_encode($response);
		}
		public function view_cart_item(){
			$userdata = $this->session->userdata('userdata');
			$data['add_bel_cust_css']  = base_url('assets/legal_services/css/pakage_details.css');
			$data['add_bel_cust_js'] = base_url('assets/legal_services/js/legal_services.js');
// 			if(!empty($userdata)){
//                $user_saved_cart = $this->pakages_model->fetch_user_cart_order($userdata['user_id']);
// 				echo "<pre>";
// 				print_r($user_saved_cart);
// 				echo "</pre>";
// 				for ($h=0; $h<count($user_saved_cart) ;$h++) { 
// 					$cart_data[] = array(
// 		    			'id'  => $user_saved_cart[$h]['pakages_type_id'],
// 		    			'price' => $user_saved_cart[$h]['price_after_discount'],
// 		    			'qty' => $user_saved_cart[$h]['quantity_ordered'],
// 						'name' => $user_saved_cart[$h]['pakages_type']['pakages_type'],
// 		    			'options' => array(
// 		    			'pakages_details' => $user_saved_cart[$h]['pakages_type']['pakages_details'],
// 		    			'discounted_price' => $user_saved_cart[$h]['discount_price'],
// 						'final_price' => $user_saved_cart[$h]['actual_price'],
// 		    			'order_type_id' => $user_saved_cart[$h]['order_type_id']
// 		    	),
// 		    	    'rowid' => $user_saved_cart[$h]['cart_row_id']
// );	
// 				}
// 				if(count($cart_data)>0){
// 			        $cart_count = $this->cart->contents();
// 			        if(empty($cart_count)){
// 					$this->cart->insert($cart_data);
// 				}
// 				}
// 			}
				// echo "<pre>";
				// print_r($this->cart->contents());
				// echo "</pre>";
				$data['saved_cart'] = $this->pakages_model->fetch_placed_pakages();
                $this->load->front_view('view_cart_item',$data);
            }
		public function remove_cart_item(){
        $userdata = $this->session->userdata('userdata');
	    $rowid = $this->input->post('item_rowid');
        $cart_contents = $this->cart->get_item($rowid);
        $cart_update_data = array(
            'rowid'   => $rowid,
            'qty'     => 0
        );
		$this->cart->update($cart_update_data);
        $data = array(
            'msg' => 'Item Successfully Removed From Cart',
            'cart_count' => count($this->cart->contents()),
            'cart_total_amount' => $this->cart->total()
        );
        echo json_encode($data);
        $this->pakages_model->delete_order($cart_update_data['rowid'],$userdata['user_id']);

    }
    public function update_cart_qty(){
    	$userdata = $this->session->userdata('userdata');
        $this->form_validation->set_rules('prod_qty', 'Quantity','required|numeric',array('numeric' => 'Only digits are allowed'));
        if ($this->form_validation->run() != FALSE){
    	$prod_qty = $this->input->post('prod_qty');
    	$row_id =   $this->input->post('rowid');
    	$cart_update_data = array(
            'rowid'   => $row_id,
            'qty'     => $prod_qty
        );
        $this->cart->update($cart_update_data);
        $cart_contents = $this->cart->get_item($row_id);
        $data = array(
            'msg' => 'Quantity has been Successfully Updated',
            'price' => $cart_contents['options']['final_price'],
            'cart_total_amount' => $this->cart->total(),
            );
        echo json_encode($data);
        $this->pakages_model->update_cart_quantity($prod_qty,$cart_update_data['rowid'],$userdata['user_id']);
	}
}
	public function generate_orderid(){
    $user_id = $this->input->post('user_order_id');
    $order_id = time().mt_rand().$user_id;
    if(count($this->cart->contents())>0){
    if(isset($order_id) && $order_id != ''){
    $this->pakages_model->insert_order_id($user_id,$order_id);
     }
       $response['attr'] = 'true';
       $response['redirect'] =  base_url('checkout-pakage/'.$order_id);
    }else{
      $response['attr'] = 'false';
  	}
  	echo json_encode($response);
	}
	public function checkout_pakages($order_id){
		$this->form_validation->set_rules('final_amount','Final Amount','required');
		$this->form_validation->set_rules('unique_order_id','Order Id','required');
		$this->form_validation->set_rules('payment_type','Payment Type','required');
		if(count($this->session->userdata('checkout_data'))>0){
        $this->session->unset_userdata('checkout_data');
		}
		if ($this->form_validation->run() != FALSE){
		 	$userdata = $this->session->userdata('userdata');
		 	$payment_total = $this->input->post('final_amount');
		 	$payment_type = $this->input->post('payment_type');
		 	$unique_order_id = $this->input->post('unique_order_id');
		 	$order_data = array('unique_order_id' => $unique_order_id);
		 	$checkout_data = array('order_id' => $unique_order_id,
		 						'final_amount' => $payment_total);
		 	$this->session->set_userdata('checkout_data',$checkout_data);
			$this->pakages_model->save_update_order_data($order_data,$userdata['user_id']);
		 	
		 $this->payment_gateway($payment_type,$payment_total);
		 }
		$data['fetch_payment_type'] = $this->pakages_model->fetch_payment_type();
		$data['add_bel_cust_css'] = base_url('assets/legal_services/css/pakage_details.css');
		$data['order_id'] = $order_id;
		$this->load->front_view('checkout_method',$data);
	}
	public function payment_gateway($payment_type,$total_price){
		$this->session->set_userdata('payment_gateway',$payment_type);

        $this->load->helper('payment_gateway');
        $gateway_data = array(
            'payment_url' => 'https://sandboxsecure.payu.in/_payment',
            'merchant_id' => 'ealDQKvi',
            'salt' => 'wqo5b1lwTA',
            'payment_form_name' => 'payuForm',
            'payment_form_data' => array(
                'key' => 'ealDQKvi',
                'txnid' => '1213dfds5656521',
                'amount' => $total_price,
                'productinfo' => 'ghdsfkdshfdshfkjsd',
                'firstname' => 'Ravi',
                'email' => 'ravi.winlife@gmail.com',
                'phone' => '8149452903',
                'surl' => base_url('payment-success'),
                'furl' => base_url('payment-failed'),
                'service_provider' => 'payu_paisa',
                // 'hash' => strtolower(hash('sha512', $hash_string))
            ),
            'hash_key_value_squence' => array(
                'key' => 'ealDQKvi',
                'txnid' => '1213dfds5656521',
                'amount' => $total_price,
                'productinfo' => 'ghdsfkdshfdshfkjsd',
                'firstname' => 'Ravi',
                'email' => 'ravi.winlife@gmail.com',
                'udf1' => '',
                'udf2' => '',
                'udf3' => '',
                'udf4' => '',
                'udf5' => '',
                'udf6' => '',
                'udf7' => '',
                'udf8' => '',
                'udf9' => '',
                'udf10' => '',
                'salt' => 'wqo5b1lwTA'
            )
        );
		 payment_gateway($gateway_data);
	}
	 public function payment_success(){
        $payment_gateway = $this->session->userdata('payment_gateway');
        $userdata = $this->session->userdata('userdata');
        if ($payment_gateway != ''){
        	$payment_type_data = array(
                    'payment_type_id' => $payment_gateway,
                    'order_status' => 'Placed',
                    'payment_status' => 'Paid',
                    'ordered_date'      => date('Y-m-d'),
             );
          $this->pakages_model->save_update_order_data($payment_type_data,$userdata['user_id']) ;
            }
			$this->cart->destroy();
            $this->session->unset_userdata($payment_gateway);
            redirect(base_url('order-placed'));
        }

     public function payment_failed(){
        $this->session->set_flashdata('frontResponse', array('msg' => 'An error occured during payment, please Try another method for payment.','class' => 'alert alert-danger'));
     }
     public function order_placed(){
     	$data['final_checkout_data'] = $this->session->userdata('checkout_data');
     	
     	$data['add_bel_cust_css'] = base_url('assets/legal_services/css/pakage_details.css');
     	$data['add_bel_cust_js'] = base_url('assets/legal_services/js/legal_services.js');
        $this->load->front_view('order_placed',$data);
    }
    public function manage_order($order_id = 0){
    	if($order_id != 0){
    		$this->pakages_model->delete_user_order($order_id);
    	}
    	$userdata = $this->session->userdata('userdata');
    	$data['fetch_all_orders'] = $this->pakages_model->fetch_all_orders($userdata['user_id']);
    	$data['add_bel_cust_js'] = base_url('assets/legal_services/js/legal_services.js');
    	$this->load->superuser_view('manage_order',$data);

    }
    public function my_orders($order_id = 0){
    	$userdata = $this->session->userdata('userdata');
    	if($order_id != 0){
    		$this->pakages_model->delete_user_order($order_id);
    	}
    	$data['fetch_user_placed_orders'] = $this->pakages_model->fetch_user_placed_orders($userdata['user_id']);
    	$this->load->superuser_view('my_orders',$data);
    }
      public function validate_form(){
    	
    	
		$this->form_validation->set_rules('user_name','Name', 'required');
		$this->form_validation->set_rules('user_mobile','Mobile', 'required|is_unique[package_user_contact.user_mobile]',array('is_unique' => 'Mobile already exsist'));
		$this->form_validation->set_rules('user_email','Email', 'valid_email|is_unique[package_user_contact.user_email]',array('is_unique' => 'Email already exsist'));

		$this->form_validation->set_rules('user_message','Message','required');
		if ($this->form_validation->run() != FALSE) {
			$userdata = $this->session->userdata('userdata');
			$user_data = array('user_name' => $this->input->post('user_name'),
							   'user_mobile' => $this->input->post('user_mobile'),
							   'user_email' => $this->input->post('user_email'),
							   'user_city' => $this->input->post('user_city'),
							   'user_message' => $this->input->post('user_message') );
			$user_callback_form = $this->pakages_model->callback_form_details($user_data);
			echo json_encode($user_callback_form);
		    
		}
	
			
    }

 }
    