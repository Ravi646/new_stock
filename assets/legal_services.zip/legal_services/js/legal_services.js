$('.order_cart').click(function(){
	var pakages_id = $(this).data('pakages_id');
	var order_type_id = $(this).data('order_type_id');
	// var here = $(this);
	$.ajax({
	url: base_url('pakages-cart'),
	// dataType:'JSON',
    data:{pakages_id:pakages_id,order_type_id:order_type_id},
    type: 'POST',
    success:function(data){
      // alert('Added to Cart Successfully');
      $('#add_cart').modal('show');
    // var order_alert = '<div class="modal fade" id="reset_password" tabindex="-1" role="dialog" aria-labelledby="loginModalLabel" aria-hidden="true"><div class="modal-dialog modal-sm" role="document"><div class="modal-content"><div class="modal-body"><div class="form-group has-feedback"><h5>Reset link has been sent to your registered email id</h5></div></div><div class="modal-footer"><button type="button" class="btn btn-danger" data-dismiss="modal">Close</button></div></div></div></div>
      $('.orderNo').html(data);
    }
	});
});
$('.goto-cart').click(function(){
	var pakages_id = $(this).data('pakages_type_id');
	$.ajax({
	url: base_url('cart-items'),
	data: {pakages_id:pakages_id},
	dataType:'JSON',
	type:'POST',
	success:function(result){
		if(result.attr == 'false'){
        document.location.href = result.redirect;
		}else{
        document.location.href = result.redirect;
		}
	}
	});
});
$('.qty_update').on('change', function(){
    var rowid = $(this).data('rowid');
    var max_qty = parseInt(10);
    var min_qty = parseInt(1);
	if(/\D/.test($(this).val())){
		alert('Only digits are allowed');
		return false;
	}
    var prod_qty = $(this).val();
    var here = $(this);
    if (prod_qty > max_qty) {
        alert('You can order max '+max_qty+' products');
        $(this).val(max_qty);
        return false;
    }
	if (prod_qty < min_qty) {
        alert('You have to order at least '+min_qty+' products');
        $(this).val(min_qty);
        return false;
    }
	$.ajax({
        dataType:'Json',
        data:{
            rowid:rowid,
            prod_qty:prod_qty,
        },
        type: 'post',
        url: base_url('update-qty'), 
       success: function(result){
            $('#quantity_change').modal('show');
           	here.closest('div').find('.final_price').html('₹'+ result.price);
            $('.dhead-rght').html('TOTAL PAYMENT AMOUNT :₹'+result.cart_total_amount);
			$('.sub_total').html('Sub Total:&nbsp&nbsp₹'+result.cart_total_amount);
		}
    });
});
$('.remove_cart_item').click(function(){
	var item_rowid = $(this).data('item_row_id');
	$(this).closest('.pakages').remove();
	$.ajax({
	url: base_url('remove-cart'),
	data: {item_rowid:item_rowid},
	dataType:'JSON',
	type:'POST',
	success:function(result){
		// alert('item has been successfully removed');
		    $('.dhead-lft').html('MY CART ('+result.cart_count+'ITEMS )');
			$('.dhead-rght').html('TOTAL PAYMENT AMOUNT :₹'+result.cart_total_amount);
			$('.sub_total').html('Sub Total:&nbsp&nbsp₹'+result.cart_total_amount);
			$('.remove_item').modal('show');
			$('.remove_item').on("hidden.bs.modal", function () {
				location.reload();
			});
	}
	});
});
$('.proceed_payment').click(function(){
	var user_order_id = $(this).data('user_checkout_id');
	$.ajax({
	url: base_url('orderid-generate'),
	data: {user_order_id:user_order_id},
	dataType:'JSON',
	type:'POST',
	success:function(result){
		if(result.attr == 'true'){
        document.location.href = result.redirect;
		}else{
        $('#present_items').modal('show');
		}
	}
});
});
$("[data-toggle=popover]").popover({
    html: true, 
	content: function() {
          return $('#popover-content').html();
        }
});
$( document ).ready(function(){
	$("#callback").validate({
		rules:{

user_name:"required",
			user_mobile:{
				required:true,
                minlength:10,
				maxlength:15
				
			},
			user_message:"required",
			user_email:"email"

		},
		messages:{
			user_name:"Please fill your name",
			user_mobile:{
			required:"Please fill your mobile",
			minlength:"minimum 10 digits are required",
			maxlength:"maximum length is 15 digits"
			},
			user_message:"Please type any message",
			user_email:"Please enter a valid email"
		}
	});
$('.callback-btn').click(function(){
	var user_name = $('.user_name').val();
    var user_mobile = $('.user_mobile').val();
	var user_email = $('.user_email').val();
	var user_city = $('.user_city').val();
	var user_message = $('.user_message').val();
	if ($("#callback").valid()) {
	$.ajax({
	url: base_url('pakages-enquiry'),
	data: {user_name:user_name,user_mobile:user_mobile,user_email:user_email,user_city:user_city,user_message:user_message},
	dataType:'JSON',
	type:'POST',
	success:function(result){
		    if(result.status == 'true'){
  			$('.callback-form').html('<div class="alert-success"><h4>!We will contact you soon!</h4></div>')
		   }
		   else{
  			$('.callback-form').html('<div class="danger-success"><h4>!We will contact you soon!</h4></div>')
		   }
		}
});
}
});
});

